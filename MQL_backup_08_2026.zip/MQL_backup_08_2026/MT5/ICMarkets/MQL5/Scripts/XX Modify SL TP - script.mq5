﻿//+------------------------------------------------------------------+
//|                                    XX Modify SL TP - script.mq5  |
//|                                          Copyright 2017,fxMeter. |
//|                            https://www.mql5.com/en/users/fxmeter |
//|  Port 1:1 từ bản MQL4 sang MQL5 — giữ nguyên logic gốc            |
//+------------------------------------------------------------------+
#property copyright "Copyright 2017,fxMeter."
#property link      "https://www.mql5.com/en/users/fxmeter"
#property version   "2.00"
#property script_show_inputs

input double InpStopLoss   = 200.0; // StopLoss Pips
input double InpTakeProfit = 200.0; // TakeProfit Pips

//--- Số dòng lỗi tối đa hiển thị trong hộp Alert (phần còn lại xem tab Experts)
#define MAX_ALERT_ERROR_LINES 10

//+------------------------------------------------------------------+
//| Hàm chính của script                                             |
//+------------------------------------------------------------------+
void OnStart()
  {
   double StopLoss   = InpStopLoss;
   double TakeProfit = InpTakeProfit;

//--- Quy đổi pip -> point cho sàn 5/3 chữ số (giống hệt bản gốc)
   if(_Digits == 5 || _Digits == 3)
     {
      TakeProfit *= 10;
      StopLoss   *= 10;
     }

//--- Không có position nào -> thoát im lặng
   if(PositionsTotal() == 0)
      return;

//--- Kiểm tra quyền giao dịch (cả terminal lẫn chương trình MQL)
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))
     {
      Alert("Không được phép giao dịch: hãy bật nút AutoTrading trên terminal.");
      return;
     }
   if(!MQLInfoInteger(MQL_TRADE_ALLOWED))
     {
      Alert("Không được phép giao dịch: script chưa được cấp quyền trade.");
      return;
     }

//--- Cả hai ô đều bằng 0 -> không có gì để sửa
   if(StopLoss == 0 && TakeProfit == 0)
     {
      Alert("Không có SL/TP nào cần sửa (cả hai ô đều bằng 0).");
      return;
     }

//--- Neo vào GIÁ HIỆN TẠI (không neo vào giá vào lệnh) — đúng như bản gốc.
//--- Bản gốc dùng Bid cho cả lệnh Buy lẫn Sell, ở đây giữ nguyên như vậy.
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);

   double tpbuy  = NormalizeDouble(bid + TakeProfit * _Point, _Digits);
   double slbuy  = NormalizeDouble(bid - StopLoss   * _Point, _Digits);

   double tpsell = NormalizeDouble(bid - TakeProfit * _Point, _Digits);
   double slsell = NormalizeDouble(bid + StopLoss   * _Point, _Digits);

//--- Bộ đếm kết quả
   int    cntOk        = 0;   // sửa thành công
   int    cntUnchanged = 0;   // SL/TP tính ra trùng khít -> bỏ qua
   int    cntFail      = 0;   // broker từ chối
   string errLines[];         // danh sách dòng lỗi chi tiết

   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong ticket = PositionGetTicket(i); // hàm này đã select luôn position
      if(ticket == 0)
         continue;

      //--- Chỉ xử lý symbol của chart hiện tại
      if(PositionGetString(POSITION_SYMBOL) != _Symbol)
         continue;

      long   posType = PositionGetInteger(POSITION_TYPE);
      double curSL   = PositionGetDouble(POSITION_SL);
      double curTP   = PositionGetDouble(POSITION_TP);

      double sl = 0.0, tp = 0.0;
      string sType = "";

      if(posType == POSITION_TYPE_BUY)
        {
         sType = "BUY ";
         //--- Ô = 0 thì giữ nguyên giá trị cũ của position
         sl = (StopLoss   != 0) ? slbuy : curSL;
         tp = (TakeProfit != 0) ? tpbuy : curTP;
        }
      else
         if(posType == POSITION_TYPE_SELL)
           {
            sType = "SELL";
            sl = (StopLoss   != 0) ? slsell : curSL;
            tp = (TakeProfit != 0) ? tpsell : curTP;
           }
         else
            continue;

      sl = NormalizeDouble(sl, _Digits);
      tp = NormalizeDouble(tp, _Digits);

      //--- Trùng khít với SL/TP hiện có -> bỏ qua, không gửi lệnh
      if(NormalizeDouble(curSL, _Digits) == sl && NormalizeDouble(curTP, _Digits) == tp)
        {
         cntUnchanged++;
         PrintFormat("#%I64u %s — không thay đổi (SL=%s TP=%s)",
                     ticket, sType,
                     DoubleToString(sl, _Digits), DoubleToString(tp, _Digits));
         continue;
        }

      //--- Gửi yêu cầu sửa SL/TP
      MqlTradeRequest req;
      ZeroMemory(req);
      MqlTradeResult  res;
      ZeroMemory(res);

      req.action   = TRADE_ACTION_SLTP;
      req.position = ticket;
      req.symbol   = _Symbol;
      req.sl       = sl;
      req.tp       = tp;

      bool ok = OrderSend(req, res) && res.retcode == TRADE_RETCODE_DONE;

      if(ok)
        {
         cntOk++;
         PrintFormat("#%I64u %s — sửa thành công (SL=%s TP=%s)",
                     ticket, sType,
                     DoubleToString(sl, _Digits), DoubleToString(tp, _Digits));
        }
      else
        {
         cntFail++;
         string cmt = res.comment;
         if(StringLen(cmt) == 0)
            cmt = "không có mô tả";
         string line = StringFormat("  #%I64u %s — broker từ chối: %u %s",
                                    ticket, sType, res.retcode, cmt);
         int n = ArraySize(errLines);
         ArrayResize(errLines, n + 1);
         errLines[n] = line;
         Print(line, "  (SL=", DoubleToString(sl, _Digits),
               " TP=", DoubleToString(tp, _Digits), ")");
        }
     } //for

//--- Không có position nào thuộc symbol này -> thoát im lặng
   if(cntOk == 0 && cntUnchanged == 0 && cntFail == 0)
      return;

//--- Gom tất cả thành MỘT Alert duy nhất
   string msg = "Modify SL TP — " + _Symbol + "\n";
   msg += "Thành công: "     + IntegerToString(cntOk)        + " lệnh\n";
   msg += "Không thay đổi: " + IntegerToString(cntUnchanged) + " lệnh\n";
   msg += "Thất bại: "       + IntegerToString(cntFail)      + " lệnh";

   int total = ArraySize(errLines);
   int shown = (total > MAX_ALERT_ERROR_LINES) ? MAX_ALERT_ERROR_LINES : total;
   for(int k = 0; k < shown; k++)
      msg += "\n" + errLines[k];
   if(total > shown)
      msg += "\n  … và " + IntegerToString(total - shown) + " lệnh khác (xem tab Experts)";

   Print(msg);
   Alert(msg);
  }
//+------------------------------------------------------------------+
