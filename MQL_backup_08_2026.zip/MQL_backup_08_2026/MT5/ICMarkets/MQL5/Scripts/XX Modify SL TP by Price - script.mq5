﻿//+------------------------------------------------------------------+
//|                                  XX Modify SL TP by Price.mq5    |
//|                                          Copyright 2017,fxMeter. |
//|                            https://www.mql5.com/en/users/fxmeter |
//+------------------------------------------------------------------+
#property copyright "Copyright 2017,fxMeter."
#property link      "https://www.mql5.com/en/users/fxmeter"
#property version   "1.00"
#property script_show_inputs

input double InpStopLossPrice   = 0.0; // Stop Loss Price
input double InpTakeProfitPrice = 0.0; // Take Profit Price

#define MAX_ALERT_LINES 10             // Số dòng lỗi tối đa hiển thị trong Alert

//+------------------------------------------------------------------+
//| Script program start function                                    |
//| Gán thẳng mức giá người dùng nhập làm SL/TP cho mọi position      |
//| đang mở của symbol trên chart hiện tại.                          |
//+------------------------------------------------------------------+
void OnStart()
  {
//--- Không có position nào thì thoát im lặng
   if(PositionsTotal()==0)
      return;

//--- Kiểm tra quyền giao dịch của terminal và của chính script
   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))
     {
      Alert("Không được phép giao dịch: hãy bật nút AutoTrading trên terminal.");
      return;
     }
   if(!MQLInfoInteger(MQL_TRADE_ALLOWED))
     {
      Alert("Không được phép giao dịch: script chưa được cấp quyền trade.");
      return;
     }

//--- Cả 2 ô đều bằng 0 thì không có gì để sửa
   if(InpStopLossPrice==0.0 && InpTakeProfitPrice==0.0)
     {
      Alert("Không có SL/TP nào cần sửa (cả hai ô đều bằng 0).");
      return;
     }

//--- Chuẩn hoá giá người dùng nhập theo số chữ số thập phân của symbol
   double inpSL = (InpStopLossPrice  ==0.0) ? 0.0 : NormalizeDouble(InpStopLossPrice,   _Digits);
   double inpTP = (InpTakeProfitPrice==0.0) ? 0.0 : NormalizeDouble(InpTakeProfitPrice, _Digits);

   int    okCount=0;        // Số lệnh sửa thành công
   int    skipCount=0;      // Số lệnh không thay đổi (SL/TP đã trùng khít)
   string failLines[];      // Danh sách mô tả từng lệnh thất bại
   int    failCount=0;

//--- Duyệt ngược toàn bộ position (MT5 chỉ chứa position thị trường,
//--- pending order nằm ở OrdersTotal nên không bị đụng tới)
   for(int i=PositionsTotal()-1; i>=0; i--)
     {
      ulong ticket=PositionGetTicket(i);   // Hàm này đã select luôn position
      if(ticket==0)
         continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol)
         continue;

      long   type    = PositionGetInteger(POSITION_TYPE);
      double curSL   = PositionGetDouble(POSITION_SL);
      double curTP   = PositionGetDouble(POSITION_TP);
      bool   isBuy   = (type==POSITION_TYPE_BUY);
      string typeStr = isBuy ? "BUY " : "SELL";

      //--- Giá tham chiếu để kiểm tra hợp lệ:
      //--- Buy đóng bằng Bid, Sell đóng bằng Ask
      double refPrice = isBuy ? SymbolInfoDouble(_Symbol,SYMBOL_BID)
                              : SymbolInfoDouble(_Symbol,SYMBOL_ASK);

      //--- Ô nào bằng 0 thì giữ nguyên giá trị cũ của position
      double newSL = (inpSL==0.0) ? curSL : inpSL;
      double newTP = (inpTP==0.0) ? curTP : inpTP;

      //--- Kiểm tra hợp lệ, chỉ với ô mà người dùng thực sự có nhập
      bool badSL=false, badTP=false;
      if(inpSL!=0.0)
         badSL = isBuy ? !(inpSL<refPrice) : !(inpSL>refPrice);
      if(inpTP!=0.0)
         badTP = isBuy ? !(inpTP>refPrice) : !(inpTP<refPrice);

      if(badSL || badTP)
        {
         //--- Không tự hoán đổi SL/TP, chỉ báo lỗi thật cụ thể
         string reason;
         if(badSL && badTP)
            reason=StringFormat("SL và TP đều không hợp lệ (SL %s, TP %s, giá %s)",
                                DoubleToString(inpSL,_Digits),
                                DoubleToString(inpTP,_Digits),
                                DoubleToString(refPrice,_Digits));
         else
            if(badSL)
               reason=StringFormat("SL %s không hợp lệ (phải %s giá %s)",
                                   DoubleToString(inpSL,_Digits),
                                   isBuy ? "<" : ">",
                                   DoubleToString(refPrice,_Digits));
            else
               reason=StringFormat("TP %s không hợp lệ (phải %s giá %s)",
                                   DoubleToString(inpTP,_Digits),
                                   isBuy ? ">" : "<",
                                   DoubleToString(refPrice,_Digits));

         AddFail(failLines,failCount,ticket,typeStr,reason);
         continue;
        }

      //--- SL/TP mới trùng khít giá trị hiện có thì bỏ qua, khỏi gửi lệnh
      if(NormalizeDouble(newSL-curSL,_Digits)==0.0 &&
         NormalizeDouble(newTP-curTP,_Digits)==0.0)
        {
         skipCount++;
         PrintFormat("#%I64u %s — không thay đổi (SL/TP đã đúng như yêu cầu)",ticket,typeStr);
         continue;
        }

      //--- MQL5 không có OrderModify, phải dùng TRADE_ACTION_SLTP
      MqlTradeRequest req;
      ZeroMemory(req);
      MqlTradeResult  res;
      ZeroMemory(res);

      req.action   = TRADE_ACTION_SLTP;
      req.position = ticket;
      req.symbol   = _Symbol;
      req.sl       = NormalizeDouble(newSL,_Digits);
      req.tp       = NormalizeDouble(newTP,_Digits);

      bool ok = OrderSend(req,res) && res.retcode==TRADE_RETCODE_DONE;

      if(ok)
        {
         okCount++;
         PrintFormat("#%I64u %s — OK: SL %s / TP %s",ticket,typeStr,
                     DoubleToString(req.sl,_Digits),DoubleToString(req.tp,_Digits));
        }
      else
        {
         string cmt=res.comment;
         if(StringLen(cmt)==0)
            cmt="(không có mô tả)";
         AddFail(failLines,failCount,ticket,typeStr,
                 StringFormat("broker từ chối: %d %s",(int)res.retcode,cmt));
        }
     }//for

//--- Không có position nào thuộc symbol này => thoát im lặng
   if(okCount==0 && skipCount==0 && failCount==0)
      return;

//--- Gom mọi kết quả thành MỘT Alert duy nhất
   string msg=StringFormat("Modify SL TP by Price — %s\nThành công: %d lệnh\nKhông thay đổi: %d lệnh\nThất bại: %d lệnh",
                           _Symbol,okCount,skipCount,failCount);

   for(int i=0; i<failCount && i<MAX_ALERT_LINES; i++)
      msg+="\n  "+failLines[i];

   if(failCount>MAX_ALERT_LINES)
      msg+=StringFormat("\n  … và %d lệnh khác (xem tab Experts)",failCount-MAX_ALERT_LINES);

   Print(msg);
   Alert(msg);
  }
//+------------------------------------------------------------------+
//| Ghi nhận một lệnh thất bại: in chi tiết ra Experts và lưu lại     |
//| để tổng hợp vào Alert cuối cùng.                                 |
//+------------------------------------------------------------------+
void AddFail(string &lines[],int &count,ulong ticket,string typeStr,string reason)
  {
   string line=StringFormat("#%I64u %s — %s",ticket,typeStr,reason);
   ArrayResize(lines,count+1);
   lines[count]=line;
   count++;
   Print(line);
  }
//+------------------------------------------------------------------+
