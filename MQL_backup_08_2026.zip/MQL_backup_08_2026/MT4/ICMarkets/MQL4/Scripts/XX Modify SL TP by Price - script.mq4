﻿//+------------------------------------------------------------------+
//|                                        Modify SL TP by Price.mq4 |
//|                                          Copyright 2017,fxMeter. |
//|                            https://www.mql5.com/en/users/fxmeter |
//+------------------------------------------------------------------+
#property copyright "Copyright 2017,fxMeter."
#property link      "https://www.mql5.com/en/users/fxmeter"
#property version   "1.00"
#property strict
#property show_inputs
#include <stdlib.mqh>

input double InpStopLossPrice   = 0.0; // Stop Loss Price
input double InpTakeProfitPrice = 0.0; // Take Profit Price

#define MAX_ALERT_LINES 10             // Số dòng lỗi tối đa hiển thị trong Alert

//+------------------------------------------------------------------+
//| So sánh 2 mức giá (tránh sai số dấu phẩy động)                    |
//+------------------------------------------------------------------+
bool SamePrice(double a,double b)
  {
   return(MathAbs(a-b)<Point*0.5);
  }
//+------------------------------------------------------------------+
//| Script program start function                                    |
//+------------------------------------------------------------------+
void OnStart()
  {
//--- Không có lệnh nào thì thoát im lặng
   if(OrdersTotal()==0) return;

   if(!IsTradeAllowed())
     {
      Alert("Không được phép giao dịch: hãy bật nút AutoTrading trên terminal.");
      return;
     }

//--- Giá người dùng nhập, đã chuẩn hoá theo số chữ số thập phân của symbol
   double slInput=NormalizeDouble(InpStopLossPrice,Digits);
   double tpInput=NormalizeDouble(InpTakeProfitPrice,Digits);

//--- Cả 2 ô đều bằng 0 => không có gì để sửa
   if(slInput==0.0 && tpInput==0.0)
     {
      Alert("Không có SL/TP nào cần sửa (cả hai ô đều bằng 0).");
      return;
     }

//--- Bộ đếm kết quả
   int okCount=0;        // sửa thành công
   int skipCount=0;      // trùng giá trị cũ => không thay đổi
   int failCount=0;      // thất bại (không hợp lệ hoặc broker từ chối)

   string failLines[];   // danh sách mô tả từng lệnh thất bại
   ArrayResize(failLines,0);

   double sl=0.0,tp=0.0;
   color  clr=clrNONE;

//--- Duyệt ngược danh sách lệnh đang mở
   for(int i=OrdersTotal()-1; i>=0; i--)
     {
      if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES)) break;

      //--- Chỉ symbol của chart hiện tại và chỉ lệnh thị trường (bỏ qua lệnh chờ)
      if(OrderSymbol()!=Symbol() || OrderType()>=2) continue;

      bool   isBuy = (OrderType()==OP_BUY);
      string sType = (isBuy ? "BUY " : "SELL");
      //--- Buy đối chiếu với Bid (giá đóng lệnh), Sell đối chiếu với Ask
      double refPrice = (isBuy ? Bid : Ask);
      clr = (isBuy ? clrBlue : clrRed);

      //--- Ô nào bằng 0 thì giữ nguyên giá trị cũ của chính lệnh đó
      sl = (slInput!=0.0 ? slInput : OrderStopLoss());
      tp = (tpInput!=0.0 ? tpInput : OrderTakeProfit());
      sl = NormalizeDouble(sl,Digits);
      tp = NormalizeDouble(tp,Digits);

      //--- Kiểm tra hợp lệ: chỉ xét ô mà người dùng thực sự có nhập
      bool slBad=false, tpBad=false;
      if(slInput!=0.0)
         slBad = (isBuy ? !(slInput<refPrice) : !(slInput>refPrice));
      if(tpInput!=0.0)
         tpBad = (isBuy ? !(tpInput>refPrice) : !(tpInput<refPrice));

      if(slBad || tpBad)
        {
         //--- Không hợp lệ: tuyệt đối không tự hoán đổi SL/TP, chỉ ghi nhận lý do
         string reason;
         string slSign = (isBuy ? "<" : ">");
         string tpSign = (isBuy ? ">" : "<");

         if(slBad && tpBad)
            reason="SL và TP đều không hợp lệ";
         else
            if(slBad)
               reason=StringConcatenate("SL ",DoubleToString(slInput,Digits),
                                        " không hợp lệ (phải ",slSign," giá ",
                                        DoubleToString(refPrice,Digits),")");
            else
               reason=StringConcatenate("TP ",DoubleToString(tpInput,Digits),
                                        " không hợp lệ (phải ",tpSign," giá ",
                                        DoubleToString(refPrice,Digits),")");

         AddFail(failLines,OrderTicket(),sType,reason);
         failCount++;
         continue;
        }

      //--- Trùng khít giá trị hiện có => bỏ qua để tránh lỗi 1 "no changes"
      if(SamePrice(sl,OrderStopLoss()) && SamePrice(tp,OrderTakeProfit()))
        {
         skipCount++;
         Print("#",OrderTicket()," ",sType," — không thay đổi (SL/TP đã đúng giá).");
         continue;
        }

      //--- Gửi lệnh sửa
      if(OrderModify(OrderTicket(),OrderOpenPrice(),sl,tp,0,clr))
        {
         okCount++;
         Print("#",OrderTicket()," ",sType," — OK: SL=",DoubleToString(sl,Digits),
               " TP=",DoubleToString(tp,Digits));
        }
      else
        {
         int err=GetLastError();
         AddFail(failLines,OrderTicket(),sType,
                 StringConcatenate("broker từ chối: ",IntegerToString(err)," ",ErrorDescription(err)));
         failCount++;
        }
     }//for

//--- Không có lệnh nào thuộc symbol này => thoát im lặng
   if(okCount==0 && skipCount==0 && failCount==0)
      return;

//--- Gom kết quả thành MỘT Alert duy nhất
   string head=StringConcatenate("Modify SL TP by Price — ",Symbol());
   string msg=head+"\n"+
              "Thành công: "+IntegerToString(okCount)+" lệnh\n"+
              "Không thay đổi: "+IntegerToString(skipCount)+" lệnh\n"+
              "Thất bại: "+IntegerToString(failCount)+" lệnh";

   int total=ArraySize(failLines);
   int shown=MathMin(total,MAX_ALERT_LINES);
   for(int k=0; k<shown; k++)
      msg=msg+"\n"+failLines[k];
   if(total>shown)
      msg=msg+"\n… và "+IntegerToString(total-shown)+" lệnh khác (xem tab Experts)";

//--- Print in đầy đủ, không giới hạn số dòng
   Print(head,": thành công ",okCount,", không thay đổi ",skipCount,", thất bại ",failCount);
   for(int k=0; k<total; k++)
      Print(failLines[k]);

   Alert(msg);
  }
//+------------------------------------------------------------------+
//| Thêm một dòng mô tả lệnh thất bại vào mảng kết quả                |
//+------------------------------------------------------------------+
void AddFail(string &arr[],int ticket,string sType,string reason)
  {
   int n=ArraySize(arr);
   ArrayResize(arr,n+1);
   arr[n]=StringConcatenate("  #",IntegerToString(ticket)," ",sType," — ",reason);
  }
//+------------------------------------------------------------------+
