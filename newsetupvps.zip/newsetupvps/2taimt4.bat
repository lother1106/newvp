@echo off
setlocal

:: ===== Require Admin =====
net session >nul 2>&1
if %errorLevel% neq 0 (
  echo Dang yeu cau quyen Administrator...
  powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
  exit /b
)

:: ===== Paths =====
set "DL_DIR=C:\Setup\Downloads"
set "LOG_DIR=C:\Setup\Logs"
if not exist "C:\Setup" mkdir "C:\Setup"
if not exist "%DL_DIR%" mkdir "%DL_DIR%"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

set "LOG=%LOG_DIR%\mt_install.log"
echo ===== MT INSTALL START %DATE% %TIME% ===== > "%LOG%"

:: ===== URLs =====
set "URL_MT5_IC=https://download.mql5.com/cdn/web/18040/mt5/icmarketssc5setup.exe"
set "URL_MT4_IC=https://download.mql5.com/cdn/web/18036/mt4/icmarketssc4setup.exe"
set "URL_MT4_TICK=https://download.terminal.free/cdn/web/17409/mt4/tickmill4setup.exe"
set "URL_MT5_TICK=https://download.terminal.free/cdn/web/19497/mt5/tickmill5setup.exe"

:: ===== Files =====
set "F_MT5_IC=%DL_DIR%\ic_mt5_setup.exe"
set "F_MT4_IC=%DL_DIR%\ic_mt4_setup.exe"
set "F_MT4_TICK=%DL_DIR%\tickmill_mt4_setup.exe"
set "F_MT5_TICK=%DL_DIR%\tickmill_mt5_setup.exe"

:: Danh sach terminal.exe da co truoc khi cai - dung de phat hien ban cai moi
set "SNAP=%LOG_DIR%\terminals_snapshot.txt"

echo.
echo [1/3] Download installers...
call :DOWNLOAD "%URL_MT5_IC%"   "%F_MT5_IC%"
call :DOWNLOAD "%URL_MT4_IC%"   "%F_MT4_IC%"
call :DOWNLOAD "%URL_MT4_TICK%" "%F_MT4_TICK%"
call :DOWNLOAD "%URL_MT5_TICK%" "%F_MT5_TICK%"

echo.
echo [2/3] Install /auto + cho cai xong that su...

:: Ghi lai cac terminal dang co, de biet cai nao la moi
powershell -NoProfile -ExecutionPolicy Bypass -Command "$c=@(); foreach($r in @($env:ProgramFiles,${env:ProgramFiles(x86)})){ if($r -and (Test-Path $r)){ $c += (Get-ChildItem \"$r\*\terminal.exe\",\"$r\*\terminal64.exe\" -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName }) } }; Set-Content -Path '%SNAP%' -Value $c"
call :INSTALL_AUTO "%F_MT5_IC%"   "MT5 IC"
call :INSTALL_AUTO "%F_MT4_IC%"   "MT4 IC"
call :INSTALL_AUTO "%F_MT4_TICK%" "MT4 Tickmill"
call :INSTALL_AUTO "%F_MT5_TICK%" "MT5 Tickmill"

echo.
echo [3/3] First launch 20s then close - khong tao shortcut...
call :FIRST_LAUNCH

echo.
if defined SETUP_FAILED (
  echo HOAN TAT NHUNG CO LOI - xem log: %LOG%
  echo ===== MT INSTALL END - WITH ERRORS %DATE% %TIME% ===== >> "%LOG%"
  if not defined RUNALL pause
  exit /b 1
)
echo DONE. Log: %LOG%
echo ===== MT INSTALL END %DATE% %TIME% ===== >> "%LOG%"
if not defined RUNALL pause
exit /b 0


:: ==========================
:: Download (TLS1.2 + certutil fallback)
:: ==========================
:DOWNLOAD
set "URL=%~1"
set "OUT=%~2"

echo - Download: %URL%
echo [DL] %URL% -^> %OUT% >> "%LOG%"

del /q "%OUT%" >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -UseBasicParsing -Uri '%URL%' -OutFile '%OUT%' -ErrorAction Stop } catch { exit 1 }" >> "%LOG%" 2>&1

if not exist "%OUT%" (
  echo   PowerShell fail -^> certutil...
  echo [DL] PowerShell fail -^> certutil >> "%LOG%"
  certutil -urlcache -split -f "%URL%" "%OUT%" >> "%LOG%" 2>&1
)

:: Kiem tra file tai ve co dung la .exe khong (2 byte dau phai la "MZ", va >= 1MB).
:: Chi kiem tra "co file" la khong du: certutil van luu ca trang loi thanh file.
powershell -NoProfile -ExecutionPolicy Bypass -Command "if(!(Test-Path '%OUT%')){exit 1}; $fs=[System.IO.File]::OpenRead('%OUT%'); $b=New-Object byte[] 2; $n=$fs.Read($b,0,2); $len=$fs.Length; $fs.Close(); if($n -lt 2 -or $b[0] -ne 77 -or $b[1] -ne 90 -or $len -lt 1000000){exit 1}; exit 0"
if %errorLevel% neq 0 (
  echo   [!] FAIL download - file tai ve khong phai .exe hop le
  echo [FAIL] Download %URL% - not a valid EXE >> "%LOG%"
  call :DUMP_BAD "%OUT%"
  if exist "%OUT%" del /f /q "%OUT%"
  set "SETUP_FAILED=1"
  exit /b 0
)

for %%A in ("%OUT%") do (
  echo   [OK] Saved: %OUT% (%%~zA bytes^)
  echo [OK] Saved: %OUT% (%%~zA bytes^) >> "%LOG%"
)
exit /b 0


:: ==========================
:: Install (best effort /auto)
:: ==========================
:INSTALL_AUTO
set "EXE=%~1"
set "NAME=%~2"

if not exist "%EXE%" (
  echo - Install: %NAME% (SKIP - missing^)
  echo [SKIP] %NAME% missing %EXE% >> "%LOG%"
  exit /b 0
)

echo - Install: %NAME% (/auto)
echo [INS] %NAME% start >> "%LOG%"

:: LUU Y: file setup nay chi la stub ~4.4MB. No giai nen ra %TEMP%, de lai tien trinh
:: con roi THOAT NGAY - nen start /wait tra ve lien va KHONG cho duoc.
:: Vi vay phai do bang ket qua that: cho den khi co terminal.exe moi xuat hien.
start "" /wait "%EXE%" /auto
echo [INS] %NAME% stub exit=%errorLevel% >> "%LOG%"

echo   Stub da thoat, dang theo doi installer...
:: Cho theo HOAT DONG chu khong cho theo ket qua:
::   - con tien trinh *setup* dang chay, HOAC terminal.exe vua bi ghi  -> coi la dang ban
::   - im lang lien tuc 45 giay                                        -> ket luan da xong
:: Nho vay: cai that thi cho du lau; da cai san thi thoat sau ~50 giay, khong treo 15 phut.
:: Ma thoat: 0 = co thay doi | 2 = khong co gi thay doi | 1 = het gio 20 phut
powershell -NoProfile -ExecutionPolicy Bypass -Command "$t0=Get-Date; $before=@(); if(Test-Path '%SNAP%'){ $before=@(Get-Content '%SNAP%') }; $dead=$t0.AddMinutes(20); $quiet=$null; $cur=@(); do { Start-Sleep -Seconds 5; $busy=$false; if(@(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match 'setup' }).Count -gt 0){ $busy=$true }; $cur=@(); foreach($r in @($env:ProgramFiles,${env:ProgramFiles(x86)})){ if($r -and (Test-Path $r)){ $cur += (Get-ChildItem \"$r\*\terminal.exe\",\"$r\*\terminal64.exe\" -ErrorAction SilentlyContinue) } }; if(@($cur | Where-Object { $_.LastWriteTime -gt (Get-Date).AddSeconds(-30) }).Count -gt 0){ $busy=$true }; if($busy){ $quiet=$null } elseif(-not $quiet){ $quiet=Get-Date } } while( ((-not $quiet) -or (((Get-Date)-$quiet).TotalSeconds -lt 45)) -and (Get-Date) -lt $dead ); $chg=@($cur | Where-Object { ($before -notcontains $_.FullName) -or ($_.LastWriteTime -gt $t0) }); Set-Content -Path '%SNAP%' -Value @($cur | ForEach-Object { $_.FullName }); if((Get-Date) -ge $dead){ exit 1 }; if($chg.Count -eq 0){ exit 2 }; $chg | ForEach-Object { Write-Host ('    -^> ' + $_.FullName) }; exit 0"
set "RC=%errorLevel%"
if "%RC%"=="0" (
  echo   [OK] %NAME% da cai xong
  echo [OK] %NAME% installed >> "%LOG%"
) else if "%RC%"=="2" (
  echo   [--] %NAME%: khong co gi thay doi - co the da cai san tu truoc
  echo [NOCHANGE] %NAME% - khong co terminal moi hoac duoc cap nhat >> "%LOG%"
) else (
  echo   [!] FAIL: %NAME% - het gio cho, installer khong ket thuc
  echo [FAIL] %NAME% - timeout >> "%LOG%"
  set "SETUP_FAILED=1"
)
exit /b 0


:: ==========================
:: Ghi lai file hong trong ra sao (de biet vi sao tai that bai)
:: ==========================
:DUMP_BAD
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='%~1'; if(-not (Test-Path $p)){ Write-Output '       [dump] khong co file nao duoc tao'; exit 0 }; $h=[System.IO.File]::ReadAllBytes($p); if($h.Length -eq 0){ Write-Output '       [dump] file rong 0 byte'; exit 0 }; $k=[Math]::Min(64,$h.Length); $t=''; for($i=0;$i -lt $k;$i++){ $c=$h[$i]; if($c -ge 32 -and $c -lt 127){ $t+=[char]$c } else { $t+='.' } }; Write-Output ('       [dump] size=' + $h.Length + ' bytes | dau file: ' + $t)" >> "%LOG%" 2>&1
exit /b 0

:: ==========================
:: First launch terminals for 20s then close
:: ==========================
:FIRST_LAUNCH
powershell -NoProfile -ExecutionPolicy Bypass -Command "$roots=@(); if($env:ProgramFiles -and (Test-Path $env:ProgramFiles)){$roots+=$env:ProgramFiles}; if(${env:ProgramFiles(x86)} -and (Test-Path ${env:ProgramFiles(x86)})){$roots+=${env:ProgramFiles(x86)}}; $terms=@(); foreach($r in $roots){ $terms += Get-ChildItem -Path $r -Recurse -ErrorAction SilentlyContinue -Include terminal.exe,terminal64.exe }; $terms=$terms | Sort-Object FullName -Unique; foreach($t in $terms){ try{ $p=Start-Process -FilePath $t.FullName -PassThru; Start-Sleep -Seconds 20; if(!$p.HasExited){ $p.CloseMainWindow()|Out-Null; Start-Sleep 3; if(!$p.HasExited){ Stop-Process -Id $p.Id -Force } } } catch{} }" >> "%LOG%" 2>&1
exit /b 0