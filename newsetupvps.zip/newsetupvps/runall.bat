@echo off
setlocal EnableExtensions

:: ============================================================
:: Chay toan bo setup chi bang MOT file.
::
::   1set-up.bat  - tat IE ESC + dat wallpaper
::   2taimt4.bat  - tai va cai MT4/MT5, mo lan dau
::   3backup.bat  - tai backup roi khoi phuc config
::
:: CHAY TUAN TU. Da thu cho 1 chay song song voi 2 nhung bo di, vi hai ly do:
::   - Chi tiet kiem duoc ~20 giay tren tong 15-30 phut, khong dang.
::   - 1set-up ket thuc bang rundll32 UpdatePerUserSystemParameters. Lenh nay
::     phat tin hieu toi MOI cua so dang mo va DUNG CHO tung cua so tra loi.
::     Neu no chay dung luc 2taimt4 dang mo/dong 4 terminal MetaTrader thi rat
::     de xung dot. Chay 1 truoc thi luc do chua co terminal nao.
::
:: 3 bat buoc dung sau 2: no can thu muc terminal va file origin.txt, hai thu
:: chi sinh ra sau khi 2 cai xong va mo terminal lan dau.
:: ============================================================

cd /d "%~dp0"

:: ---- Nang quyen MOT LAN duy nhat, ngay tai day ----
:: Ban cu khong lam viec nay. Moi script con tu nang quyen rieng, nen khi chua
:: la Administrator thi moi lenh call deu bat mot cua so moi roi tra ve NGAY,
:: khien ca 3 script chay chong len nhau va "if errorlevel" mat het y nghia.
net session >nul 2>&1
if %errorLevel% neq 0 (
  echo Dang yeu cau quyen Administrator...
  powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
  exit /b
)

:: Bao cho script con biet dang chay tu runall, de chung khong dung o pause
set "RUNALL=1"

echo ============================================
echo CHAY TOAN BO SETUP
echo ============================================
echo.

echo ===== [1/3] 1set-up.bat =====
call "%~dp01set-up.bat"
if errorlevel 1 goto :ERR_1

echo.
echo ===== [2/3] 2taimt4.bat =====
call "%~dp02taimt4.bat"
if errorlevel 1 goto :ERR_2

echo.
echo ===== [3/3] 3backup.bat =====
call "%~dp03backup.bat"
if errorlevel 1 goto :ERR_3

echo.
echo ============================================
echo TAT CA DA HOAN TAT
echo ============================================
echo Log cai dat MT : C:\Setup\Logs\mt_install.log
echo Log khoi phuc  : C:\Setup\Logs\mql_backup_restore.log
pause
exit /b 0


:ERR_1
echo.
echo !!! DUNG LAI - 1set-up.bat that bai
pause
exit /b 1

:ERR_2
echo.
echo !!! DUNG LAI - 2taimt4.bat that bai
echo Xem log: C:\Setup\Logs\mt_install.log
pause
exit /b 1

:ERR_3
echo.
echo !!! DUNG LAI - 3backup.bat that bai
echo Xem log: C:\Setup\Logs\mql_backup_restore.log
pause
exit /b 1
