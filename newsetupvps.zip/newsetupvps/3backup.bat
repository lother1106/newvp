@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul

:: ============================================================
:: GOP 3getbackup.bat + 4backup.bat THANH MOT FILE
::   PHASE 1: tai file backup .zip ve va giai nen ra C:\MQL_backup
::   PHASE 2: khoi phuc vao cac terminal trong %APPDATA%\MetaQuotes\Terminal
:: Neu PHASE 1 that bai thi DUNG LAI, khong khoi phuc tu du lieu rong.
:: ============================================================

set "URL=https://github.com/lother1106/newvp/blob/21f44b36cee5556792f6a754e897b951632bacc6/MQL_backup_08_2026.zip?raw=true"
set "BACKUP_ROOT=C:\MQL_backup"
set "ZIP_FILE=%TEMP%\MQL_backup.zip"
set "TERMINAL_ROOT=%APPDATA%\MetaQuotes\Terminal"
set "COPY_CONFIG=1"
set "DEBUG_LEVEL=2"

set "LOG_DIR=C:\Setup\Logs"
if not exist "C:\Setup" mkdir "C:\Setup" >nul 2>&1
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%" >nul 2>&1
set "LOG=%LOG_DIR%\mql_backup_restore.log"
del /f /q "%LOG%" >nul 2>&1

echo ============================================
echo MQL BACKUP - TAI VE VA KHOI PHUC
echo ============================================
echo BACKUP_ROOT   : %BACKUP_ROOT%
echo TERMINAL_ROOT : %TERMINAL_ROOT%
echo LOG           : %LOG%
echo.

>>"%LOG%" echo ============================================================
>>"%LOG%" echo ===== START %DATE% %TIME% =====
>>"%LOG%" echo URL=%URL%
>>"%LOG%" echo BACKUP_ROOT=%BACKUP_ROOT%
>>"%LOG%" echo TERMINAL_ROOT=%TERMINAL_ROOT%
>>"%LOG%" echo COPY_CONFIG=%COPY_CONFIG%
>>"%LOG%" echo ============================================================

echo [PHASE 1/2] Tai va giai nen backup...
call :GET_BACKUP
if errorlevel 1 (
  echo.
  echo [FATAL] Khong lay duoc backup. Dung lai, khong khoi phuc.
  >>"%LOG%" echo [FATAL] GET_BACKUP failed
  if not defined RUNALL pause
  exit /b 1
)

echo.
echo [PHASE 2/2] Khoi phuc vao terminal...
call :DO_RESTORE
if errorlevel 1 (
  echo.
  echo [FATAL] Khoi phuc that bai. Xem log: %LOG%
  if not defined RUNALL pause
  exit /b 1
)

echo.
echo DONE. Log: %LOG%
>>"%LOG%" echo ===== DONE %DATE% %TIME% =====
if not defined RUNALL pause
exit /b 0


:: ============================================================
:: PHASE 1 - tai ve + giai nen
:: ============================================================
:GET_BACKUP
if not exist "%BACKUP_ROOT%" mkdir "%BACKUP_ROOT%" >nul 2>&1
if exist "%ZIP_FILE%" del /f /q "%ZIP_FILE%" >nul 2>&1

echo   Tai ve: %ZIP_FILE%
>>"%LOG%" echo [DL] %URL% to %ZIP_FILE%

:: Chon cong cu tai bang goto thay vi if long nhau. Ban goc dung if long nhau
:: nen %errorlevel% ben trong khoi ngoac lay gia tri CU tu truoc khi vao khoi,
:: khien nhanh bitsadmin khong bao gio chay dung.
where curl >nul 2>&1
if not errorlevel 1 goto :GB_CURL
where bitsadmin >nul 2>&1
if not errorlevel 1 goto :GB_BITS
goto :GB_PS

:GB_CURL
echo   [DL] dung curl
curl -L --retry 3 --connect-timeout 15 -o "%ZIP_FILE%" "%URL%" >>"%LOG%" 2>&1
goto :GB_CHECKZIP

:GB_BITS
echo   [DL] curl khong co, dung bitsadmin
bitsadmin /transfer "MQLBackup" /download /priority normal "%URL%" "%ZIP_FILE%" >>"%LOG%" 2>&1
goto :GB_CHECKZIP

:GB_PS
echo   [DL] dung PowerShell TLS 1.2
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; try { (New-Object Net.WebClient).DownloadFile('%URL%','%ZIP_FILE%') } catch { exit 1 }" >>"%LOG%" 2>&1
goto :GB_CHECKZIP

:GB_CHECKZIP
:: 2 byte dau cua file ZIP phai la "PK". Chi kiem tra "co file" la khong du:
:: cong cu tai ve van luu ca trang loi HTML thanh file nhu thuong.
powershell -NoProfile -ExecutionPolicy Bypass -Command "if(-not (Test-Path '%ZIP_FILE%')){exit 1}; $fs=[System.IO.File]::OpenRead('%ZIP_FILE%'); $b=New-Object byte[] 2; $n=$fs.Read($b,0,2); $len=$fs.Length; $fs.Close(); if($n -lt 2 -or $b[0] -ne 80 -or $b[1] -ne 75 -or $len -lt 1024){exit 1}; exit 0"
if errorlevel 1 (
  echo   [ERR] File tai ve khong phai ZIP hop le
  >>"%LOG%" echo [FAIL] downloaded file is not a valid ZIP
  call :DUMP_BAD "%ZIP_FILE%"
  if exist "%ZIP_FILE%" del /f /q "%ZIP_FILE%" >nul 2>&1
  exit /b 1
)
for %%A in ("%ZIP_FILE%") do echo   [OK] Tai xong, %%~zA bytes
for %%A in ("%ZIP_FILE%") do >>"%LOG%" echo [OK] downloaded %%~zA bytes

echo   Giai nen vao: %BACKUP_ROOT%
where tar >nul 2>&1
if not errorlevel 1 goto :GB_TAR
goto :GB_PSZIP

:GB_TAR
echo   [UNZIP] dung tar
tar -xf "%ZIP_FILE%" -C "%BACKUP_ROOT%" >>"%LOG%" 2>&1
goto :GB_FLATTEN

:GB_PSZIP
echo   [UNZIP] tar khong co, thu Expand-Archive
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Get-Command Expand-Archive -ErrorAction SilentlyContinue) { Expand-Archive -Path '%ZIP_FILE%' -DestinationPath '%BACKUP_ROOT%' -Force; exit 0 } else { exit 1 }" >>"%LOG%" 2>&1
if not errorlevel 1 goto :GB_FLATTEN

echo   [UNZIP] dung VBS legacy
set "VBS=%TEMP%\unzip_mql.vbs"
> "%VBS%" echo Set fso = CreateObject("Scripting.FileSystemObject")
>>"%VBS%" echo If Not fso.FolderExists("%BACKUP_ROOT%") Then fso.CreateFolder("%BACKUP_ROOT%")
>>"%VBS%" echo Set sh = CreateObject("Shell.Application")
>>"%VBS%" echo Set src = sh.NameSpace("%ZIP_FILE%")
>>"%VBS%" echo Set dst = sh.NameSpace("%BACKUP_ROOT%")
>>"%VBS%" echo If (src Is Nothing) Then WScript.Quit 2
>>"%VBS%" echo dst.CopyHere src.Items, 16
>>"%VBS%" echo WScript.Sleep 2000
cscript //nologo "%VBS%" >>"%LOG%" 2>&1
del /f /q "%VBS%" >nul 2>&1

:GB_FLATTEN
:: Zip co the long them mot hoac nhieu cap, va ten thu muc ben trong KHONG co dinh
:: - ban thuc te la "MQL_backup_08_2026". Ban goc chi tim dung ten "MQL_backup" nen
:: khong bao gio go duoc, khien C:\MQL_backup\MT4\... khong ton tai va buoc khoi phuc
:: am tham that bai nhung van in DONE.
:: Cach moi: chung nao thu muc goc chi chua DUNG 1 thu muc con va khong co file nao
:: thi keo noi dung cua no len mot cap. Lap toi da 5 lan.
echo   Go bo cac cap thu muc long nhau...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$r='%BACKUP_ROOT%'; for($i=0;$i -lt 5;$i++){ $d=@(Get-ChildItem -LiteralPath $r -Directory -Force -ErrorAction SilentlyContinue); $f=@(Get-ChildItem -LiteralPath $r -File -Force -ErrorAction SilentlyContinue); if($d.Count -eq 1 -and $f.Count -eq 0){ $inner=$d[0].FullName; Get-ChildItem -LiteralPath $inner -Force | ForEach-Object { Move-Item -LiteralPath $_.FullName -Destination $r -Force }; Remove-Item -LiteralPath $inner -Recurse -Force -ErrorAction SilentlyContinue; Write-Output ('flattened: ' + $inner) } else { break } }" >>"%LOG%" 2>&1

:: Nghiem thu: phai co file VA phai thay thu muc MT4 hoac MT5 thi cau truc moi dung
powershell -NoProfile -ExecutionPolicy Bypass -Command "$r='%BACKUP_ROOT%'; $n=@(Get-ChildItem -LiteralPath $r -Recurse -File -ErrorAction SilentlyContinue).Count; $ok=(Test-Path (Join-Path $r 'MT4')) -or (Test-Path (Join-Path $r 'MT5')); Write-Output ('extracted files: ' + $n + ' | has MT4 or MT5: ' + $ok); if($n -eq 0 -or -not $ok){exit 1}; exit 0" >>"%LOG%" 2>&1
if errorlevel 1 (
  echo   [ERR] Cau truc backup khong dung - khong thay thu muc MT4 hoac MT5
  >>"%LOG%" echo [FAIL] backup structure invalid - no MT4/MT5 folder
  exit /b 1
)
echo   [OK] Giai nen xong
exit /b 0


:: ============================================================
:: Ghi lai file hong trong ra sao, de biet vi sao tai that bai
:: ============================================================
:DUMP_BAD
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p='%~1'; if(-not (Test-Path $p)){ Write-Output '       [dump] khong co file nao duoc tao'; exit 0 }; $h=[System.IO.File]::ReadAllBytes($p); if($h.Length -eq 0){ Write-Output '       [dump] file rong 0 byte'; exit 0 }; $k=[Math]::Min(64,$h.Length); $t=''; for($i=0;$i -lt $k;$i++){ $c=$h[$i]; if($c -ge 32 -and $c -lt 127){ $t+=[char]$c } else { $t+='.' } }; Write-Output ('       [dump] size=' + $h.Length + ' bytes | dau file: ' + $t)" >>"%LOG%" 2>&1
exit /b 0


:: ============================================================
:: PHASE 2 - khoi phuc vao tung terminal
:: ============================================================
:DO_RESTORE
if not exist "%BACKUP_ROOT%" (
  echo   [ERR] Khong thay BACKUP_ROOT: %BACKUP_ROOT%
  >>"%LOG%" echo [FATAL] BACKUP_ROOT not found: %BACKUP_ROOT%
  exit /b 1
)
if not exist "%TERMINAL_ROOT%" (
  echo   [ERR] Khong thay TERMINAL_ROOT: %TERMINAL_ROOT%
  >>"%LOG%" echo [FATAL] TERMINAL_ROOT not found: %TERMINAL_ROOT%
  exit /b 1
)
:: Dung if mot dong, KHONG dung khoi ngoac. Ban goc viet 2^>^&1 ben trong khoi,
:: dau ^ khong tao thanh chuyen huong ma bi dir nhan nham la ten file can liet ke,
:: nen no in "File Not Found" ra man hinh moi lan chay.
if "%DEBUG_LEVEL%"=="2" >>"%LOG%" echo [DBG] Terminal folders:
if "%DEBUG_LEVEL%"=="2" dir /ad /b "%TERMINAL_ROOT%" >>"%LOG%" 2>&1
>>"%LOG%" echo ===== START RESTORE PROCESS =====
for /d %%D in ("%TERMINAL_ROOT%\*") do call :MAYBE_PROCESS "%%D"
exit /b 0


:MAYBE_PROCESS
setlocal
set "DST=%~1"
if exist "%DST%\origin.txt" (
  endlocal & call :PROCESS "%DST%"
) else (
  if "%DEBUG_LEVEL%"=="2" >>"%LOG%" echo [DBG] SKIP no origin.txt: %DST%
  endlocal & goto :EOF
)
goto :EOF


:PROCESS
setlocal EnableDelayedExpansion
set "DST=%~1"
set "ORIGIN="

echo.
echo ==== CHECK TERMINAL: !DST!
>>"%LOG%" echo ------------------------------------------------------------
>>"%LOG%" echo [STEP] PROCESS DST=!DST!

for /f "usebackq delims=" %%O in (`powershell -NoProfile -Command "if(Test-Path '%DST%\origin.txt'){(Get-Content '%DST%\origin.txt' -TotalCount 1).Trim()} else {''}"`) do set "ORIGIN=%%O"

>>"%LOG%" echo [DBG] ORIGIN=!ORIGIN!

:: ---------- Detect BROKER ----------
set "BROKER="
echo(!ORIGIN!| findstr /I /C:"IC Markets" >nul
if not errorlevel 1 set "BROKER=ICMarkets"

echo(!ORIGIN!| findstr /I /C:"Tickmill" >nul
if not errorlevel 1 set "BROKER=Tickmill"

:: ---------- Detect TYPE ----------
set "TYPE="
echo(!ORIGIN!| findstr /I /C:"MetaTrader 5" >nul
if not errorlevel 1 set "TYPE=MT5"

echo(!ORIGIN!| findstr /I /C:"MetaTrader 4" >nul
if not errorlevel 1 set "TYPE=MT4"

if "!TYPE!"=="" (
  echo(!ORIGIN!| findstr /I /R "\<MT5\>" >nul
  if not errorlevel 1 set "TYPE=MT5"
)

if "!TYPE!"=="" (
  echo(!ORIGIN!| findstr /I /R "\<MT4\>" >nul
  if not errorlevel 1 set "TYPE=MT4"
)

>>"%LOG%" echo [DBG] DETECT BROKER=!BROKER! TYPE=!TYPE!
echo DETECTED BROKER: !BROKER!
echo DETECTED TYPE: !TYPE!

if "!BROKER!"=="" (
  >>"%LOG%" echo [SKIP] Unknown Broker. ORIGIN="!ORIGIN!"
  endlocal & goto :EOF
)

if "!TYPE!"=="" (
  >>"%LOG%" echo [SKIP] Unknown Type. ORIGIN="!ORIGIN!"
  endlocal & goto :EOF
)

set "SRC=%BACKUP_ROOT%\!TYPE!\!BROKER!"
>>"%LOG%" echo [DBG] SRC PATH=!SRC!
echo SRC PATH: !SRC!

if not exist "!SRC!" (
  >>"%LOG%" echo [ERR] SRC NOT FOUND: !SRC!
  endlocal & goto :EOF
)

powershell -NoProfile -Command "if(Test-Path '!SRC!'){(Get-ChildItem -LiteralPath '!SRC!' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object).Count}else{0}" >"%TEMP%\_mql_count.txt"
set /p SRC_COUNT=<"%TEMP%\_mql_count.txt"
del "%TEMP%\_mql_count.txt" 2>nul
>>"%LOG%" echo [DBG] SRC file count=!SRC_COUNT!

if "!SRC_COUNT!"=="0" (
  >>"%LOG%" echo [WARN] Backup appears EMPTY under SRC: !SRC!
)

if /I "!TYPE!"=="MT4" (
  call :RESTORE_MT4 "!SRC!" "!DST!"
) else (
  call :RESTORE_MT5 "!SRC!" "!DST!"
)

>>"%LOG%" echo [OK ] PROCESS done DST=!DST!
endlocal & goto :EOF


:ROBO
setlocal EnableDelayedExpansion
set "SRC=%~1"
set "DST=%~2"

>>"%LOG%" echo [COPY] "%SRC%" to "%DST%"

if not exist "%SRC%" (
  >>"%LOG%" echo [WARN] Source not exist: "%SRC%"
  endlocal & exit /b 0
)

if not exist "%DST%" mkdir "%DST%" 2>nul

robocopy "%SRC%" "%DST%" /E /R:1 /W:1 /NP >>"%LOG%"
set "RC=!ERRORLEVEL!"
>>"%LOG%" echo [RC] robocopy RC=!RC!

endlocal & exit /b 0


:RESTORE_MT4
setlocal
>>"%LOG%" echo [STEP] RESTORE_MT4 SRC=%~1 DST=%~2 COPY_CONFIG=%COPY_CONFIG%
call :ROBO "%~1\templates"       "%~2\templates"
call :ROBO "%~1\MQL4\Indicators" "%~2\MQL4\Indicators"
call :ROBO "%~1\MQL4\Scripts"    "%~2\MQL4\Scripts"
if "%COPY_CONFIG%"=="1" call :ROBO "%~1\config" "%~2\config"
>>"%LOG%" echo [OK ] RESTORE_MT4 done
endlocal & exit /b 0


:ROBO_ALT
:: Copy tu nguon uu tien; neu khong co thi thu nguon du phong cau truc cu.
::   %1 = nguon dung chuan | %2 = nguon cau truc cu | %3 = dich
if exist "%~1" goto :RA_MAIN
if exist "%~2" goto :RA_ALT
>>"%LOG%" echo [MISS] khong thay nguon: "%~1"
exit /b 0

:RA_MAIN
call :ROBO "%~1" "%~3"
exit /b 0

:RA_ALT
>>"%LOG%" echo [WARN] backup dung cau truc cu: "%~2" thay vi "%~1"
call :ROBO "%~2" "%~3"
exit /b 0


:RESTORE_MT5
setlocal
>>"%LOG%" echo [STEP] RESTORE_MT5 SRC=%~1 DST=%~2 COPY_CONFIG=%COPY_CONFIG%
:: MT5 KHAC MT4: moi thu nam duoi MQL5\, ke ca Profiles.
::   template dung o  <data>\MQL5\Profiles\Templates
::   KHONG phai       <data>\Profiles\Templates   (thu muc nay MT5 khong doc)
:: Ban cu ghi vao <data>\Profiles\Templates nen file .tpl nam im mot cho,
:: va thieu han dong copy Scripts.
:: Nguon du phong: backup cua Tickmill thieu cap MQL5 nen phai chiu ca 2 kieu.
call :ROBO_ALT "%~1\MQL5\Indicators"         "%~1\Indicators"         "%~2\MQL5\Indicators"
call :ROBO_ALT "%~1\MQL5\Scripts"            "%~1\Scripts"            "%~2\MQL5\Scripts"
call :ROBO_ALT "%~1\MQL5\Profiles\Templates" "%~1\Profiles\Templates" "%~2\MQL5\Profiles\Templates"
if "%COPY_CONFIG%"=="1" call :ROBO "%~1\config" "%~2\config"
>>"%LOG%" echo [OK ] RESTORE_MT5 done
endlocal & exit /b 0
