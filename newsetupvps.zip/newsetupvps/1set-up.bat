@echo off
setlocal

:: ==========================
:: Require Admin
:: ==========================
net session >nul 2>&1
if %errorLevel% neq 0 (
  echo Dang yeu cau quyen Administrator...
  powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
  exit /b
)

echo.
echo Tat IE Enhanced Security Configuration...

:: Admin ESC OFF
reg add "HKLM\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4B3F-8CFC-4F3A74704073}" ^
/v IsInstalled /t REG_DWORD /d 0 /f >nul

:: User ESC OFF
reg add "HKLM\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4B3F-8CFC-4F3A74704073}" ^
/v IsInstalled /t REG_DWORD /d 0 /f >nul

echo IE ESC da tat.
echo.

:: ==========================
:: Wallpaper Setup
:: ==========================

:: Luu y: trong file .bat phai viet %% de gui di duoc dau % (neu viet %20 thi batch hieu la tham so %2)
set "IMAGE_URL=https://raw.githubusercontent.com/lother1106/newvp/07c67476f7bbee661d3a35f85a68e59954897c93/Khung%%20Nen%%2008-2026.png"
set "SAVE_PATH=C:\Setup\wallpaper.png"

if not exist "C:\Setup" mkdir "C:\Setup"

echo Dang tai wallpaper...

powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -UseBasicParsing -Uri '%IMAGE_URL%' -OutFile '%SAVE_PATH%' -ErrorAction Stop } catch { exit 1 }"

if not exist "%SAVE_PATH%" (
  echo PowerShell tai that bai, thu bang certutil...
  certutil -urlcache -split -f "%IMAGE_URL%" "%SAVE_PATH%" >nul 2>&1
)

:: Kiem tra file tai ve co dung la anh PNG khong (8 byte dau la chu ky PNG).
:: Chi kiem tra "file co ton tai" la khong du: certutil van luu ca trang loi 404 thanh file.
powershell -NoProfile -ExecutionPolicy Bypass -Command "if(!(Test-Path '%SAVE_PATH%')){exit 1}; $b=[System.IO.File]::ReadAllBytes('%SAVE_PATH%'); if($b.Length -lt 8){exit 1}; $s=137,80,78,71,13,10,26,10; for($i=0;$i -lt 8;$i++){if($b[$i] -ne $s[$i]){exit 1}}; exit 0"
if %errorLevel% neq 0 (
  echo Tai anh that bai - file tai ve khong phai anh PNG hop le!
  if exist "%SAVE_PATH%" del /f /q "%SAVE_PATH%"
  if not defined RUNALL pause
  exit /b 1
)

echo Dang set wallpaper...

powershell -NoProfile -ExecutionPolicy Bypass -Command "Set-ItemProperty 'HKCU:\Control Panel\Desktop' Wallpaper '%SAVE_PATH%'; Set-ItemProperty 'HKCU:\Control Panel\Desktop' WallpaperStyle '10'; Set-ItemProperty 'HKCU:\Control Panel\Desktop' TileWallpaper '0'; rundll32.exe user32.dll,UpdatePerUserSystemParameters"

echo.
echo Setup hoan tat!
echo (Neu IE dang mo, hay dong lai va mo lai IE)
if not defined RUNALL pause